Sun Saber -- based off Beat Saber by Hyperbolic Magnetism
Coded by SunE

This game is not being used for commercial purposes; all credit and rights go to the original game:
https://beatsaber.com/


===============================================================================

"Sun Saber V-.-.exe" is the game, sample level "Xenogenesis" can be found in levels/Xenogenesis/
"Level Maker V-.-.exe" helps with the creation of Sun Saber levels.

Level Maker:
Commands while editing level:
> exit	Saves and exits the level
> add	Adds a note with the given details
> view / view range	Views a list of all the notes OR the notes inside the given range
> copy / copy range	Copies the note OR notes inside the given range
> move / move range	Moves the note OR notes inside the given range
> del / del range	Deletes the note OR notes inside the given range
> settings	Updates the level data and details
While creating level:
- Song file -- name of file with music in level, must be an .ogg file. Do not enter ".ogg" at the end.

Sun Saber:
- All settings and data is stored in "playerdata.txt", do not delete.
- Font is stored in "Teko-Regular.ttf", do not delete.
- Levels and replays are stored in "levels", do not delete folder.
- Background music is "Background.mp3", do not delete.